﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1081420_hw_2
{
    public partial class Form1 : Form
    {
        Rectangle rect; // 矩形區域
        int x = 0;
        int y = 0;
        Boolean end = false;
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    rect = new Rectangle(x + 60 * i,32+ y + 60 * j, 60, 60); // 寬高100的矩形區域
                    e.Graphics.DrawRectangle(Pens.Black, rect); // 繪出矩形
            
                   
                }

            }
        }



        private void Form1_Load(object sender, EventArgs e)
        {
            C1.Text = "";  //把按鈕設成空白
            C2.Text = "";
            C3.Text = "";
            C4.Text = "";
            C5.Text = "";
            C6.Text = "";
            C7.Text = "";
            C8.Text = "";
            C9.Text = "";
            C1.Enabled = true;
            C2.Enabled = true;
            C3.Enabled = true;
            C4.Enabled = true;
            C5.Enabled = true;
            C6.Enabled = true;
            C7.Enabled = true;
            C8.Enabled = true;
            C9.Enabled = true;
            info.Text = "訊息：";
            end = false;
        }

       

        

        private void C1_Click(object sender, EventArgs e)
        {
            Label L = (Label)sender;      
            if (L.Enabled)
            {
                L.Text = "O";//玩家
            }

            judge();   //呼叫函式
            L.Enabled = false;  //下好離手 點下後就不能再更改
                                //info.Text = L.Enabled.ToString();

            if (!end) {
                Random rd = new Random();  //使用亂數類別
                int random_index = 1 + rd.Next(9);//1+0~1+8
                while (!this.Controls.Find("C" + random_index, false)[0].Enabled)
                {
                    rd = new Random();
                    random_index = 1 + rd.Next(9);//1+0~1+8
                }
                this.Controls.Find("C" + random_index, false)[0].Text = "X";
                this.Controls.Find("C" + random_index, false)[0].Enabled = false;
                judge();   //呼叫函式
            }

           

        }

        private void computer() {
            Random rd = new Random();  //使用亂數類別
            int random_index=1+rd.Next(9);//1+0~1+8
            while (!this.Controls.Find("C" + random_index, false)[0].Enabled){
                rd = new Random();
                random_index = 1 + rd.Next(9);//1+0~1+8
            }
            /*這個方法傳回的是一個Controls陣列
            為啥是陣列呢?因為第二個參數叫"要不要搜尋子物件"
            如果是你搜尋的是容器物件,又設為True
            就可能會傳回不只一個control物件回來
            因為label1基本上是"一個"物件
            所以我都會設為False,也就是它只要找到就只會傳回一個
            所以索引一定是[0]
            如果你要找多個Label物件,用迴圈應該是
            for (int i = 0; i < 10; i++)  
            {
            this.Controls.Find("label"+i , false)[0].Text="CVX"
            }
            這樣就會把label0~label9所有它找的到的Label物件的Text屬性設為"CVX"*/
            this.Controls.Find("C" + random_index, false)[0].Text = "X";
            this.Controls.Find("C" + random_index, false)[0].Enabled = false;
            judge();   //呼叫函式
        }

        private void newGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1_Load(sender,e);
        }
        private void judge()
        {
            if (C1.Text == C2.Text && C2.Text == C3.Text && C3.Text == "O")
            {
                
                info.Text = info.Text + "You win!";
                Application.DoEvents();
                close();
                end=true;
            }
            if (C1.Text == C2.Text && C2.Text == C3.Text && C3.Text == "X")
            {
                info.Text = info.Text + "You lose!";
                Application.DoEvents();
                close();
                end = true;
            }
            if (C4.Text == C5.Text && C5.Text == C6.Text && C6.Text == "O")
            {
                info.Text = info.Text + "You win!";
                Application.DoEvents();
                close();
                end = true;
            }
            if (C4.Text == C5.Text && C5.Text == C6.Text && C6.Text == "X")
            {
                info.Text = info.Text + "You lose!";
                Application.DoEvents();
                close();
                end = true;
            }
            if (C7.Text == C8.Text && C8.Text == C9.Text && C9.Text == "O")
            {
                info.Text = info.Text + "You win!";
                Application.DoEvents();
                close();
                end = true;
            }
            if (C7.Text == C8.Text && C8.Text == C9.Text && C9.Text == "X")
            {
                info.Text = info.Text + "You lose!";
                Application.DoEvents();
                close();
                end = true;
            }
            if (C1.Text == C4.Text && C4.Text == C7.Text && C7.Text == "O")
            {
                info.Text = info.Text + "You win!";
                Application.DoEvents();
                close();
                end = true;
            }
            if (C1.Text == C4.Text && C4.Text == C7.Text && C7.Text == "X")
            {
                info.Text = info.Text + "You lose!";
                Application.DoEvents();
                close();
                end = true;
            }
            if (C2.Text == C5.Text && C5.Text == C8.Text && C8.Text == "O")
            {
                info.Text = info.Text + "You win!";
                Application.DoEvents();
                close();
                end = true;
            }
            if (C2.Text == C5.Text && C5.Text == C8.Text && C8.Text == "X")
            {
                info.Text = info.Text + "You lose!";
                Application.DoEvents();
                close();
                end = true;
            }
            if (C3.Text == C6.Text && C6.Text == C9.Text && C9.Text == "O")
            {
                info.Text = info.Text + "You win!";
                Application.DoEvents();
                close();
                end = true;
            }
            if (C3.Text == C6.Text && C6.Text == C9.Text && C9.Text == "X")
            {
                info.Text = info.Text + "You lose!";
                Application.DoEvents();
                close();
                end = true;
            }
            if (C1.Text == C5.Text && C5.Text == C9.Text && C9.Text == "O")
            {
                info.Text = info.Text + "You win!";
                Application.DoEvents();
                close();
                end = true;
            }
            if (C1.Text == C5.Text && C5.Text == C9.Text && C9.Text == "X")
            {
                info.Text = info.Text + "You lose!";
                 Application.DoEvents();
                close();
                end = true;
            }
            if (C3.Text == C5.Text && C5.Text == C7.Text && C7.Text == "O")
            {
                info.Text = info.Text + "You win!";
                Application.DoEvents();
                close();
                end = true;
            }
            if (C3.Text == C5.Text && C5.Text == C7.Text && C7.Text == "X")
            {
                info.Text = info.Text + "You lose!";
                Application.DoEvents();
                close();
                end = true;
            }
            Boolean draw = false;
            for (int i = 1; i < 10; i++) {
                if (this.Controls.Find("C" + i, false)[0].Enabled ) draw=false;
            }
            if (draw) {
                info.Text = info.Text + "Draw!";
                Application.DoEvents();
                end = true;
            }
        }
        private void close()
        {
            C1.Enabled = false;
            C2.Enabled = false;
            C3.Enabled = false;
            C4.Enabled = false;
            C5.Enabled = false;
            C6.Enabled = false;
            C7.Enabled = false;
            C8.Enabled = false;
            C9.Enabled = false;
        }
    }
}

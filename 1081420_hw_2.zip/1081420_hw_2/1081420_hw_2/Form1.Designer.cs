﻿namespace _1081420_hw_2
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.C1 = new System.Windows.Forms.Label();
            this.C2 = new System.Windows.Forms.Label();
            this.C3 = new System.Windows.Forms.Label();
            this.C4 = new System.Windows.Forms.Label();
            this.C5 = new System.Windows.Forms.Label();
            this.C6 = new System.Windows.Forms.Label();
            this.C7 = new System.Windows.Forms.Label();
            this.C8 = new System.Windows.Forms.Label();
            this.C9 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.gameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newGameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.info = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // C1
            // 
            this.C1.BackColor = System.Drawing.Color.Transparent;
            this.C1.Font = new System.Drawing.Font("新細明體", 34F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.C1.Location = new System.Drawing.Point(-1, 41);
            this.C1.Margin = new System.Windows.Forms.Padding(0);
            this.C1.Name = "C1";
            this.C1.Size = new System.Drawing.Size(92, 92);
            this.C1.TabIndex = 0;
            this.C1.Text = "O";
            this.C1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.C1.Click += new System.EventHandler(this.C1_Click);
            // 
            // C2
            // 
            this.C2.BackColor = System.Drawing.Color.Transparent;
            this.C2.Font = new System.Drawing.Font("新細明體", 34F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.C2.Location = new System.Drawing.Point(91, 41);
            this.C2.Margin = new System.Windows.Forms.Padding(0);
            this.C2.Name = "C2";
            this.C2.Size = new System.Drawing.Size(92, 92);
            this.C2.TabIndex = 1;
            this.C2.Text = "O";
            this.C2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.C2.Click += new System.EventHandler(this.C1_Click);
            // 
            // C3
            // 
            this.C3.BackColor = System.Drawing.Color.Transparent;
            this.C3.Font = new System.Drawing.Font("新細明體", 34F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.C3.Location = new System.Drawing.Point(183, 41);
            this.C3.Margin = new System.Windows.Forms.Padding(0);
            this.C3.Name = "C3";
            this.C3.Size = new System.Drawing.Size(92, 92);
            this.C3.TabIndex = 2;
            this.C3.Text = "O";
            this.C3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.C3.Click += new System.EventHandler(this.C1_Click);
            // 
            // C4
            // 
            this.C4.BackColor = System.Drawing.Color.Transparent;
            this.C4.Font = new System.Drawing.Font("新細明體", 34F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.C4.Location = new System.Drawing.Point(-1, 133);
            this.C4.Margin = new System.Windows.Forms.Padding(0);
            this.C4.Name = "C4";
            this.C4.Size = new System.Drawing.Size(92, 92);
            this.C4.TabIndex = 3;
            this.C4.Text = "O";
            this.C4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.C4.Click += new System.EventHandler(this.C1_Click);
            // 
            // C5
            // 
            this.C5.BackColor = System.Drawing.Color.Transparent;
            this.C5.Font = new System.Drawing.Font("新細明體", 34F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.C5.Location = new System.Drawing.Point(91, 133);
            this.C5.Margin = new System.Windows.Forms.Padding(0);
            this.C5.Name = "C5";
            this.C5.Size = new System.Drawing.Size(92, 92);
            this.C5.TabIndex = 4;
            this.C5.Text = "O";
            this.C5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.C5.Click += new System.EventHandler(this.C1_Click);
            // 
            // C6
            // 
            this.C6.BackColor = System.Drawing.Color.Transparent;
            this.C6.Font = new System.Drawing.Font("新細明體", 34F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.C6.Location = new System.Drawing.Point(183, 133);
            this.C6.Margin = new System.Windows.Forms.Padding(0);
            this.C6.Name = "C6";
            this.C6.Size = new System.Drawing.Size(92, 92);
            this.C6.TabIndex = 5;
            this.C6.Text = "O";
            this.C6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.C6.Click += new System.EventHandler(this.C1_Click);
            // 
            // C7
            // 
            this.C7.BackColor = System.Drawing.Color.Transparent;
            this.C7.Font = new System.Drawing.Font("新細明體", 34F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.C7.Location = new System.Drawing.Point(-1, 225);
            this.C7.Margin = new System.Windows.Forms.Padding(0);
            this.C7.Name = "C7";
            this.C7.Size = new System.Drawing.Size(92, 92);
            this.C7.TabIndex = 6;
            this.C7.Text = "O";
            this.C7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.C7.Click += new System.EventHandler(this.C1_Click);
            // 
            // C8
            // 
            this.C8.BackColor = System.Drawing.Color.Transparent;
            this.C8.Font = new System.Drawing.Font("新細明體", 34F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.C8.Location = new System.Drawing.Point(91, 225);
            this.C8.Margin = new System.Windows.Forms.Padding(0);
            this.C8.Name = "C8";
            this.C8.Size = new System.Drawing.Size(92, 92);
            this.C8.TabIndex = 7;
            this.C8.Text = "O";
            this.C8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.C8.Click += new System.EventHandler(this.C1_Click);
            // 
            // C9
            // 
            this.C9.BackColor = System.Drawing.Color.Transparent;
            this.C9.Font = new System.Drawing.Font("新細明體", 34F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.C9.Location = new System.Drawing.Point(183, 225);
            this.C9.Margin = new System.Windows.Forms.Padding(0);
            this.C9.Name = "C9";
            this.C9.Size = new System.Drawing.Size(92, 92);
            this.C9.TabIndex = 8;
            this.C9.Text = "O";
            this.C9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.C9.Click += new System.EventHandler(this.C1_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gameToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 31);
            this.menuStrip1.TabIndex = 9;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // gameToolStripMenuItem
            // 
            this.gameToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newGameToolStripMenuItem});
            this.gameToolStripMenuItem.Name = "gameToolStripMenuItem";
            this.gameToolStripMenuItem.Size = new System.Drawing.Size(76, 27);
            this.gameToolStripMenuItem.Text = "&Game";
            // 
            // newGameToolStripMenuItem
            // 
            this.newGameToolStripMenuItem.Name = "newGameToolStripMenuItem";
            this.newGameToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.newGameToolStripMenuItem.Size = new System.Drawing.Size(273, 34);
            this.newGameToolStripMenuItem.Text = "New Game";
            this.newGameToolStripMenuItem.ToolTipText = "New game";
            this.newGameToolStripMenuItem.Click += new System.EventHandler(this.newGameToolStripMenuItem_Click);
            // 
            // info
            // 
            this.info.AutoSize = true;
            this.info.Location = new System.Drawing.Point(12, 368);
            this.info.Name = "info";
            this.info.Size = new System.Drawing.Size(62, 18);
            this.info.TabIndex = 10;
            this.info.Text = "訊息：";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.info);
            this.Controls.Add(this.C9);
            this.Controls.Add(this.C8);
            this.Controls.Add(this.C7);
            this.Controls.Add(this.C6);
            this.Controls.Add(this.C5);
            this.Controls.Add(this.C4);
            this.Controls.Add(this.C3);
            this.Controls.Add(this.C2);
            this.Controls.Add(this.C1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label C1;
        private System.Windows.Forms.Label C2;
        private System.Windows.Forms.Label C3;
        private System.Windows.Forms.Label C4;
        private System.Windows.Forms.Label C5;
        private System.Windows.Forms.Label C6;
        private System.Windows.Forms.Label C7;
        private System.Windows.Forms.Label C8;
        private System.Windows.Forms.Label C9;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem gameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newGameToolStripMenuItem;
        private System.Windows.Forms.Label info;
    }
}


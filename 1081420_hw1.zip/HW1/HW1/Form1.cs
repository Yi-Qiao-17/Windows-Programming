﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HW1
{
    public partial class Form1 : Form
    {
        Rectangle rect; // 矩形區域
        int x = 0;
        int y = 0;
        int r, g, b;
        Random rd = new Random();  //使用亂數類別
        Brush b1;

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                   
                    Graphics g1 = this.CreateGraphics();
                    r = rd.Next(256); //產生0~255的亂數
                    g = rd.Next(256);
                    b = rd.Next(256);
                    b1 = new SolidBrush(Color.FromArgb(r, g, b)); //產生亂數顏色畫刷
                    g1.FillRectangle(b1, x + 50 * i, y + 50 * j, 50, 50);  //畫圓
                }

            }


        }

        


        public Form1()
        {
            InitializeComponent();
            

        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) {
                    rect = new Rectangle(x + 50 * i, y + 50 * j, 50, 50); // 寬高100的矩形區域
                    e.Graphics.DrawRectangle(Pens.Black, rect); // 繪出矩形
                    Graphics g1 = this.CreateGraphics();
                    r = rd.Next(256); //產生0~255的亂數
                    g = rd.Next(256);
                    b = rd.Next(256);
                    b1 = new SolidBrush(Color.FromArgb(r, g, b)); //產生亂數顏色畫刷
                    g1.FillRectangle(b1, x + 50 * i, y + 50 * j, 50, 50);  //畫圓
                }

            }
            

        }
    }
}
